﻿Public Class Form1

    Dim marklist As New List(Of Integer)
    Dim marklistbox As New List(Of Integer)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim mark As Integer = TextBox1.Text
        marklist.Add(mark)
        Marks.Items.Add(mark)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim total As Integer = marklist.Sum
        Dim avg As Double = total / marklist.Count
        If avg >= 95 Then
            Label1.Text = "Wow! Your average is" + Str(avg)
        ElseIf avg >= 90 And avg < 95 Then
            Label1.Text = "Congrats, your avg is" + Str(avg)
        ElseIf avg < 90 Then
            Label1.Text = "dumbass, your avg is" + Str(avg)
        End If
        marklist.Clear()
        Marks.Items.Clear()

    End Sub
End Class
